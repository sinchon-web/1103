package booleans;

public class Test01 {
	
	public static void main(String[] args) {
		boolean a=true;
		boolean b=false;
	}

}
